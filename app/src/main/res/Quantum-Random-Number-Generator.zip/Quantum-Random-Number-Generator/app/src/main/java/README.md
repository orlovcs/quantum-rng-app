todo:
 add manual random gen fall back
 make toasts to notofy if true random generated or manual fallback

    give option to turn off the api

    add multiple dice rolls, maybe 3


    How many coins?


    give # heads, #of tails